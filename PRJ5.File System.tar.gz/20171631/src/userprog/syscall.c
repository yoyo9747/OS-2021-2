#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <stdlib.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "threads/vaddr.h"
#include "devices/input.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "lib/string.h"
#include "threads/malloc.h"
static void syscall_handler (struct intr_frame *);
struct lock filesys_lock;
void
syscall_init (void) 
{
	lock_init(&wlock);
	lock_init(&rlock);
	lock_init(&filesys_lock);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");//system call handler �� 0x30�� ����Ǿ��ִ�
}

static void
syscall_handler (struct intr_frame *f UNUSED) //interupt_frame�� stack������ ����. �ʱ� esp���� system call number�� ����, �� ���Ŀ� arg������ ���ִ�
{
	if(!is_user_vaddr(f->esp))//user memory check
		exit(-1);
	switch(*(uint32_t *)(f->esp)){//system call number
		case SYS_HALT://halt, arg=0
			halt();
			break;
		case SYS_EXIT://exit, arg=1
			if(!is_user_vaddr(f->esp+4))//user memory check
				exit(-1);
			exit(*(uint32_t *)(f->esp+4));//1 argument
			break;
		case SYS_EXEC://exec, arg=1
			if(!is_user_vaddr(f->esp+4))//user memory check
				exit(-1);
			f->eax=exec((char*)*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_WAIT://wait, arg=1
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=wait(*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_CREATE:
			if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)))//user memory check
				exit(-1);
			f->eax=create((char*)*(uint32_t *)(f->esp+4),*(uint32_t *)(f->esp+8));//2 argument, return to eax
			break;
		case SYS_REMOVE:
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=remove((char*)*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_OPEN:
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=open((char*)*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_FILESIZE:
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=filesize((int)*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_READ://read, arg=3
			if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)&&is_user_vaddr(f->esp+12)))//user memory check
				exit(-1);
			f->eax=read(*(uint32_t *)(f->esp+4),(void*)*(uint32_t *)(f->esp+8),(unsigned)*(uint32_t *)(f->esp+12));//3 argument, return to eax
			break;
		case SYS_WRITE://write, arg=3
			if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)&&is_user_vaddr(f->esp+12))){//user memory check
				exit(-1);
			}
			f->eax=write(*(uint32_t *)(f->esp+4),(void*)*(uint32_t *)(f->esp+8),(unsigned)*(uint32_t *)(f->esp+12));//3 argument, return to eax
			break;
		case SYS_SEEK:
			if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)))//user memory check
				exit(-1);
			seek((int)*(uint32_t *)(f->esp+4),(unsigned)*(uint32_t *)(f->esp+8));//2 argument, no return
			break;
		case SYS_TELL:
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=tell((int)*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_CLOSE:
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			close((int)*(uint32_t *)(f->esp+4));//1 argument, no return
			break;
		case SYS_FIBONACCI://fibonacci,arg=1
			if(!(is_user_vaddr(f->esp+4)))//user memory check
				exit(-1);
			f->eax=fibonacci(*(uint32_t *)(f->esp+4));//1 argument, return to eax
			break;
		case SYS_MAX_OF_FOUR_INT://max_of_four_int,arg=4
			if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)&&is_user_vaddr(f->esp+12)&&is_user_vaddr(f->esp+16)))//user memory check
				exit(-1);
			f->eax=max_of_four_int(*(uint32_t *)(f->esp+4),*(uint32_t *)(f->esp+8),*(uint32_t *)(f->esp+12),*(uint32_t *)(f->esp+16));//4 argument, return to eax
			break;
#ifdef FILESYS
 		 case SYS_CHDIR:
			if(!is_user_vaddr(f->esp+4))
				exit(-1);	
      		f->eax = sys_chdir((char*)*(uint32_t*)(f->esp+4));
			break;

		 case SYS_MKDIR:
			if(!is_user_vaddr(f->esp+4))
				exit(-1);	
			f->eax = sys_mkdir((char*)*(uint32_t*)(f->esp+4));
			break;
		 case SYS_READDIR:
		 	if(!(is_user_vaddr(f->esp+4)&&is_user_vaddr(f->esp+8)))//user memory check
		 		exit(-1);
			f->eax=sys_readdir((int)*(uint32_t *)(f->esp+4),(char*)*(uint32_t*)(f->esp+8));
			break;
		 case SYS_ISDIR:
		 	if(!is_user_vaddr(f->esp+4))
		 		exit(-1);	
			f->eax=sys_isdir((int)*(uint32_t *)(f->esp+4));
			break;
		 case SYS_INUMBER:
			if(!is_user_vaddr(f->esp+4))
				exit(-1);
			f->eax=sys_inumber((int)*(uint32_t *)(f->esp+4));
			break;
#endif
		default:
			thread_exit();//default: thread ����
	}
}
void read_acquire(){//lock_acquire for read, open
	lock_acquire(&rlock);//lock for readercnt
	thread_current()->readercnt+=1;
	if(thread_current()->readercnt==1)
		lock_acquire(&wlock);//wlock acquire
	lock_release(&rlock);
}
void read_release(){//lock_release for read, open
	lock_acquire(&rlock);//lock for readercnt
	thread_current()->readercnt-=1;
	if(thread_current()->readercnt==0)//if readercnt==0
		lock_release(&wlock);//wlock release
	lock_release(&rlock);
}
void halt(void){
	shutdown_power_off();//halt pintos program
}
void exit(int status){
	struct thread *t=thread_current();
	printf("%s: exit(%d)\n",t->name,status);//print thread name, status
	t->exit_status=status;//thread_exit_status update
	for(int fd=2;fd<128;fd++){
		if(t->files[fd]!=NULL)//close every opened file descriptor
			close(fd);
	}
	thread_exit();//exit
}
tid_t exec(char *cmd_line){
	tid_t tid=process_execute(cmd_line);//cmd_line���� process�� execute���ش�. �ش� process_execute�Լ��� thread�� ������ �� job queue�� �־��ָ�, schedule �� �� �ش� cmd_line�� ���� �� ���̴�. ���� �� ��� �����߿� ������ �ִٸ� -1�� return �� ���̴�.
	return tid;//thread id return
}
int wait(tid_t pid){
	return process_wait(pid);//�ش� pid�� wait ���ش�. 
}
bool create (const char *file, unsigned initial_size){
	if (file==NULL){//if file string is NULL
		exit(-1);
	}
	return filesys_create(file,initial_size,false);
}
bool remove (const char *file){
	return filesys_remove(file);
}
int open (const char *file){
	int fd;
	struct thread *t=thread_current();
	if(file==NULL){//if file string is NULL
		exit(-1);
	}
	read_acquire();//lock for read(now thread can't write)
	struct file* file_opened=filesys_open(file);
	struct file_descriptor* file_d=(struct file_descriptor*)malloc(sizeof(struct file_descriptor));
	if(file_d==NULL||file_opened==NULL){
		free(file_d);
		read_release();
		return -1;
	}
	file_d->file=file_opened;
	struct inode *inode=file_get_inode(file_d->file);
	if(inode==NULL){
		read_release();
		return -1;
	}
	if(inode!=NULL&&inode_is_directory(inode)){
		file_d->dir=dir_open(inode_reopen(inode));
	}
	else
		file_d->dir=NULL;
	for(fd=2;fd<128;fd++){
		if(t->files[fd]==NULL){//find where to allocate
			t->files[fd]=file_d;
			if(strcmp(t->name,file)==0){//if file==current excuting file
				file_deny_write(t->files[fd]->file);
			}
			read_release();//lock_release
			return fd;
		}
	}
	read_release();//lock_release
	return -1;	
}
int filesize (int fd){
	return file_length(thread_current()->files[fd]->file);
}
int read(int fd, void *buffer, unsigned size){
	if(!is_user_vaddr(buffer)){//if buffer is wrong ptr
		exit(-1);
	}
	read_acquire();//lock for read(now thread can't write)
	if(fd==0){
		unsigned int tsize;
		for(tsize=1;tsize<size;tsize++)
			if(input_getc()=='\0')//'\0'�Է¶����� input�� �޴´�
				break;
		input_getc();//input_getc(manual ����)
		size=tsize;
	}
	else{
		struct thread *t=thread_current();
		if(t->files[fd]==NULL||buffer==NULL){//error
			read_release();
			exit(-1);
		}
		unsigned int tsize;
		tsize=file_read(t->files[fd]->file,buffer,size);//read
		size=tsize;
	}
	read_release();//lock_release(wlock)
	return size;//return size
}
int write(int fd, const void *buffer, unsigned size){
	if(!is_user_vaddr(buffer)||!pagedir_get_page(thread_current()->pagedir,buffer)){//if buffer is wrong ptr
		exit(-1);
	}
	lock_acquire(&wlock);//acquire wlock
	if(fd==1){
		putbuf(buffer,size);//buffer�� size��ŭ �Է��Ѵ�
	}
	else{
		struct thread *t=thread_current();
		if(t->files[fd]==NULL||buffer==NULL){//error
			lock_release(&wlock);
			exit(-1);
		}
		struct inode *inode=file_get_inode(t->files[fd]->file);
		if(inode!=NULL&&inode_is_directory(inode)){
			lock_release(&wlock);
			return -1;
		}
		if(t->files[fd]->file->deny_write){//if file==current excuting file
			lock_release(&wlock);
			return 0;
		}
		unsigned int tsize;
		tsize=file_write(t->files[fd]->file,buffer,size);//write
		size=tsize;
	}
	lock_release(&wlock);//release wlock
	return size;//size�� return
}
void seek (int fd, unsigned position){
	file_seek(thread_current()->files[fd]->file,position);
}
unsigned tell (int fd){
	return file_tell(thread_current()->files[fd]->file);
}
void close (int fd){
	struct thread *t=thread_current();
	if(t->files[fd]==NULL)//error
		exit(-1);
	if(t->files[fd]->file)
		file_close(t->files[fd]->file);
	if(t->files[fd]->dir)
		dir_close(t->files[fd]->dir);
	free(t->files[fd]);
	t->files[fd]=NULL;
}
int fibonacci(int n){
	int ans=1,bef=1,temp;
	while(n>2){
		temp=ans;
		ans=bef+ans;
		bef=temp;
		n--;
	}
	return ans;
}
int max_of_four_int(int a, int b, int c, int d){
	int max=a;
	if(max<b)
		max=b;
	if(max<c)
		max=c;
	if(max<d)
		max=d;
	return max;
}
#ifdef FILESYS

bool sys_chdir(const char *filename)
{
	if(!is_user_vaddr(filename)||!pagedir_get_page(thread_current()->pagedir,filename)){//if filename is wrong ptr
		exit(-1);
	}
  bool return_code;

  lock_acquire (&filesys_lock);
  return_code = filesys_chdir(filename);
  lock_release (&filesys_lock);

  return return_code;
}

bool sys_mkdir(const char *filename)
{
  if(!is_user_vaddr(filename)||!pagedir_get_page(thread_current()->pagedir,filename)){//if filename is wrong ptr
		exit(-1);
  }
  bool return_code;

  lock_acquire (&filesys_lock);
  return_code = filesys_create(filename, 0, true);
  lock_release (&filesys_lock);

  return return_code;
}
bool sys_readdir(int fd, char *name){
	struct thread *t=thread_current();
	lock_acquire(&filesys_lock);
	if(t->files[fd]==NULL){
		lock_release(&filesys_lock);
		return false;
	}
	struct inode *inode=file_get_inode(t->files[fd]->file);
	if(inode==NULL||!inode_is_directory(inode)){
		lock_release(&filesys_lock);
		return false;
	}
	if(t->files[fd]->dir==NULL){
		lock_release(&filesys_lock);
		return false;
	}
	bool ret= dir_readdir(t->files[fd]->dir,name);
	lock_release(&filesys_lock);
	return ret;
}
bool sys_isdir(int fd){
	struct thread *t=thread_current();
	lock_acquire(&filesys_lock);
	if(t->files[fd]==NULL){
		lock_release(&filesys_lock);
		return false;
	}
	if(t->files[fd]->file==NULL||t->files[fd]->dir==NULL){
		lock_release(&filesys_lock);
		return false;
	}
	bool ret= inode_is_directory(file_get_inode(t->files[fd]->file));
	lock_release(&filesys_lock);
	return ret;
}
int sys_inumber(int fd){
	struct thread *t=thread_current();
	lock_acquire(&filesys_lock);
	if(t->files[fd]==NULL){
		lock_release(&filesys_lock);
		return -1;
	}
	if(t->files[fd]->file==NULL){
		lock_release(&filesys_lock);
		return -1;
	}
	int ret= (int)inode_get_inumber(file_get_inode(t->files[fd]->file));
	lock_release(&filesys_lock);
	return ret;
}
#endif
