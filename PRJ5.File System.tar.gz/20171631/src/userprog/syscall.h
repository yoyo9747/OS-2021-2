#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "threads/thread.h"
void syscall_init (void);
void halt(void);
void exit(int);
tid_t exec(char *);
int wait(tid_t pid);
int read(int fd, void *buffer, unsigned size);
int write(int fd, const void *buffer, unsigned size);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
void seek (int fd, unsigned position);
unsigned tell (int fd);
void close (int fd);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);
////////////////for userprogram 2///////////////////
struct lock rlock;
struct lock wlock;
void read_acquire(void);
void read_release(void);
////////////////////////////////////////////////////

#ifdef FILESYS
bool sys_chdir(const char *filename);
bool sys_mkdir(const char *filename);
bool sys_readdir(int fd, char *filename);
bool sys_isdir(int fd);
int sys_inumber(int fd);
#endif /* userprog/syscall.h */
#endif
