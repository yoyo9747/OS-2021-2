#ifndef HUB_H
//10070
#define HUB_H

void usb_hub_init(void);


#endif
