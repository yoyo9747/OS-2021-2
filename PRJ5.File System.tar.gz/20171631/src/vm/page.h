#ifndef VM_PAGE_H
#define VM_PAGE_H
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"

#define VM_BIN 0
#define VM_FILE 1
#define VM_ANON 2

/*struct vm_entry{
	uint8_t type;//page type(BIN, FILE, ANON)
	void *vaddr;
	bool writable;//true->writable, false->no write
	bool is_loaded;//if loaded on memory
	struct file* file;//corresponding file
	struct list_elem mmap_elem;//mmap 리스트 element
	size_t offset;//offset to read
	size_t read_bytes;//size of byte
	size_t zero_bytes;//remaining byte
	size_t swap_slot;
	/////////////////////////
	struct hash_elem elem;
};
void vm_init(struct hash* vm);
unsigned vm_hash_func(const struct hash_elem *e, void *aux);
bool vm_less_func(const struct hash_elem *a,const struct hash_elem *b, void *aux);
bool insert_vme(struct hash *vm, struct vm_entry *vme);
bool delete_vme(struct hash *vm, struct vm_entry *vme);
struct vm_entry *find_vme(void *vaddr);
void vm_destroy(struct hash *vm);
bool load_file(uint8_t* kaddr, struct vm_entry* vme);
struct vm_entry *find_vme(void *vaddr);*/
#endif
