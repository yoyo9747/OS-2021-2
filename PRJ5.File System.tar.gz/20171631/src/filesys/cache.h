#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H

#include "devices/block.h"


void bc_init (void);
void bc_close (void);
void bc_read (block_sector_t sector, void *target);
void bc_write (block_sector_t sector,const void *source);

#endif
