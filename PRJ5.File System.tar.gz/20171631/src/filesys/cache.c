#include <debug.h>
#include <string.h>
#include "filesys/cache.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

#define BC_SIZE 64 //buffer cache size of 64 entry

struct bc_entry_t {
  block_sector_t sector;//disk ���� sector �ּ� ����
  uint8_t data[BLOCK_SECTOR_SIZE];//�ϳ� ����� 512B!!(sector size)
  bool occupied;//��밡������ check  
  bool dirty;     // dirty bit
  bool chance;    // chance for not being evict
};

static struct bc_entry_t cache[BC_SIZE];
static struct lock bc_lock;
static size_t clock;

void bc_init (void){//initialize buffer cache and entries
  lock_init (&bc_lock);
  clock=0;
  size_t i;
  for (i = 0; i < BC_SIZE; i++)
    cache[i].occupied = false;
}

static void bc_flush (struct bc_entry_t *entry)
{
	block_write (fs_device, entry->sector, entry->data);//flush
    entry->dirty = false;
}

void bc_close (void)
{
  lock_acquire (&bc_lock);
  size_t i;
  for (i = 0; i < BC_SIZE; i++){
    if (cache[i].dirty)//��ȿ�� entry �� �� �Ű��ش� disk��
		bc_flush(&(cache[i]));
  }
  lock_release (&bc_lock);
}
static struct bc_entry_t* bc_find (block_sector_t sector){//sector�ּҿ� �ش��ϴ� buffer cache entry ã�´�
  size_t i;
  for (i = 0; i < BC_SIZE; i++)
  {
    if ((cache[i].occupied)&&cache[i].sector == sector){
      return &(cache[i]);
    }
  }
  return NULL; //�� ã��
}

static struct bc_entry_t* bc_entry_evict (void){//cache�� ���� entry�� evict�ؾ��Ѵ�. clock algorithm ���
  while (true) {
    if (cache[clock].occupied == false)//empty entry ã��
      return &(cache[clock]);

    if (cache[clock].chance) {
      // give a second chance
      cache[clock].chance = false;
    }
    else //chance�� ���µ� occupied 
		break;
    clock =(clock+1)%BC_SIZE;
  }

  struct bc_entry_t *entry = &cache[clock];
  if (entry->dirty) {
    bc_flush (entry);
  }
  entry->occupied = false;
  return entry;
}
void bc_read (block_sector_t sector, void *target)
{
  lock_acquire (&bc_lock);

  struct bc_entry_t *entry = bc_find (sector);//cache�κ��� �������� sector�ּҸ� ���� entry�� ã���ش�
  if (entry == NULL) {//�� ã����
    entry = bc_entry_evict ();//�� entry �ϳ� �޾ƿ´�
	///�� entry�� setting���ش�.
    entry->occupied = true;
    entry->sector = sector;
    entry->dirty = false;
    block_read (fs_device, sector, entry->data);
  }

  // sector�� ����
  entry->chance = true;
  memcpy (target, entry->data, BLOCK_SECTOR_SIZE);
  lock_release (&bc_lock);
}

void bc_write (block_sector_t sector, const void *source)
{
  lock_acquire (&bc_lock);
///bc_read�� ����ϴ�.
  struct bc_entry_t *entry = bc_find(sector);
  if (entry == NULL) {
    entry = bc_entry_evict ();

    // fill in the cache entry.
    entry->occupied = true;
    entry->sector = sector;
    entry->dirty = false;
    block_read (fs_device, sector, entry->data);
  }

  // copy the data form memory into the buffer cache.
  entry->chance = true;
  entry->dirty = true;//cache�� �ش� disk �� sector ������ �ٸ���
  memcpy (entry->data, source, BLOCK_SECTOR_SIZE);

  lock_release (&bc_lock);
}
