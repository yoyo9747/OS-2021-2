#include "filesys/inode.h"
#include <list.h>
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "filesys/cache.h"
#include "threads/malloc.h"

/* Identifies an inode. */
#define INODE_MAGIC 0x494e4f44


static inline size_t bytes_to_sectors (off_t size) { return DIV_ROUND_UP (size, BLOCK_SECTOR_SIZE);}
#define min(a, b) (( (a) < (b)) ? (a) : (b))

static bool inode_reserve (struct inode_disk *disk_inode, off_t length);
static bool inode_deallocate (struct inode *inode);

static block_sector_t index_to_sector (const struct inode_disk *idisk, off_t index){//index�� �Է� ������ �ش��ϴ� sector�� ã�Ƽ� return ���ش�
  
  if (index < DIRECT_BLOCKS_COUNT) {//IF index in direct block
    return idisk->direct_blocks[index];
  }
  index-=DIRECT_BLOCKS_COUNT;
  struct inode_indirect_block_sector *indirect_idisk=calloc(1,sizeof(struct inode_indirect_block_sector));//DIRECT block�� �ƴϹǷ� indirect block�� �ʿ��ϴ�
  if (index < INDIRECT_BLOCKS_PER_SECTOR) {//IF index in single indirect block
    bc_read (idisk->indirect_block, indirect_idisk);//indirect_idisk�� sector������ ���� ���̴�.
    block_sector_t target = indirect_idisk->blocks[index];//index���� �°� sector ã����
    free(indirect_idisk);
    return target;
  }
  index-=INDIRECT_BLOCKS_PER_SECTOR;
  if (index < INDIRECT_BLOCKS_PER_SECTOR*INDIRECT_BLOCKS_PER_SECTOR) {//IF index in doubly indirect block
    off_t index_first =  index / INDIRECT_BLOCKS_PER_SECTOR;//indirect block
    off_t index_second = index % INDIRECT_BLOCKS_PER_SECTOR;//doubly indirect block(target block ����)
    bc_read (idisk->doubly_indirect_block, indirect_idisk);
    bc_read (indirect_idisk->blocks[index_first], indirect_idisk);
    block_sector_t target= indirect_idisk->blocks[index_second];
    free(indirect_idisk);
    return target;
  }
  free(indirect_idisk);
  return -1;//error, wrong index
}

static block_sector_t byte_to_sector (const struct inode *inode, off_t pos)//inode�� position�� �ش��ϴ� sector�� ã����� �� ���̴�. byte������ index�� �ٲ� ������ index_to_sector�Լ��� ȣ���� �˸��� sector�� ã�� return ���ش�.
{
  if(inode==NULL||0>pos||pos>=inode->data.length)
	  return -1;
  return index_to_sector (&inode->data, pos/BLOCK_SECTOR_SIZE);
}

static struct list open_inodes;

void inode_init (void){//initialize inode
  list_init (&open_inodes);
}

bool inode_create (block_sector_t sector, off_t length,bool is_dir)//disk�� ����� inode�� length��ŭ �Ҵ��ؼ� sector���������ش�
{
  if(length<0)
	  return false;//error
  struct inode_disk *disk_inode = NULL;
  disk_inode = calloc (1, sizeof *disk_inode);
  if(disk_inode==NULL)
	  return false;//error
  
  disk_inode->length = length;
  disk_inode->magic = INODE_MAGIC;
  disk_inode->is_dir=is_dir;
  if (inode_reserve (disk_inode,disk_inode->length)){
	bc_write (sector, disk_inode);
	free (disk_inode);
    return true;
  }
  free (disk_inode);
  return false;//error
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode * inode_open (block_sector_t sector){//sector�κ��� inode ������ �о open inode�κ��� ã�Ƽ� return ���ش�
  struct list_elem *e;
  struct inode *inode;

  /* Check whether this inode is already open. */
  for (e = list_begin (&open_inodes); e != list_end (&open_inodes);
       e = list_next (e))
    {
      inode = list_entry (e, struct inode, elem);
      if (inode->sector == sector)
        {
          inode_reopen (inode);
          return inode;
        }
    }

  /* Allocate memory. */
  inode = malloc (sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front (&open_inodes, &inode->elem);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;

  bc_read (inode->sector, &inode->data);//data �о�´�
  return inode;
}

/* Reopens and returns INODE. */
struct inode *
inode_reopen (struct inode *inode)
{
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
block_sector_t
inode_get_inumber (const struct inode *inode)
{
  return inode->sector;
}

/* Closes INODE and writes it to disk.
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void
inode_close (struct inode *inode)
{
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0)
    {
      /* Remove from inode list and release lock. */
      list_remove (&inode->elem);

      /* Deallocate blocks if removed. */
      if (inode->removed)
        {
          free_map_release (inode->sector, 1);
          inode_deallocate (inode);//inode deallocate
        }

      free (inode);
    }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void
inode_remove (struct inode *inode)
{
  ASSERT (inode != NULL);
  inode->removed = true;
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t
inode_read_at (struct inode *inode, void *buffer_, off_t size, off_t offset)
{
  uint8_t *buffer = buffer_;
  off_t bytes_read = 0;
  uint8_t *bounce = NULL;

  while (size > 0)
    {
      /* Disk sector to read, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = min(inode_left,sector_left);

      /* Number of bytes to actually copy out of this sector. */
      int chunk_size = min(size, min_left);
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Read full sector directly into caller's buffer. */
          bc_read (sector_idx, buffer + bytes_read);//buffer cache read�� �ٲ���
        }
      else
        {
          /* Read sector into bounce buffer, then partially copy
             into caller's buffer. */
          if (bounce == NULL)
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }
          bc_read (sector_idx, bounce);//buffer cache read�� �ٲ���
          memcpy (buffer + bytes_read, bounce + sector_ofs, chunk_size);
        }

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_read += chunk_size;
    }
  free (bounce);

  return bytes_read;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode).
   */
off_t
inode_write_at (struct inode *inode, const void *buffer_, off_t size,
                off_t offset)
{
  const uint8_t *buffer = buffer_;
  off_t bytes_written = 0;
  uint8_t *bounce = NULL;

  if (inode->deny_write_cnt)
    return 0;

  if( byte_to_sector(inode, offset + size - 1) == -1u ) {//extend �ʿ�!!
    // extend and reserve up to [offset + size] bytes
    if(!inode_reserve (& inode->data, offset + size))//extend �Ǵ� ��ŭ inode ���� indirect, doubly indirect block�� �ᰡ�� extend���ְ� inode block�� update �����ش�
		return 0; //reserve fail
    inode->data.length = offset + size;//length update
    bc_write (inode->sector, &inode->data);//inode block ���� update to sector
  }

  while (size > 0)
    {
      /* Sector to write, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);
      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = min(inode_left,sector_left);

      /* Number of bytes to actually write into this sector. */
      int chunk_size = min(size,min_left);
      if (chunk_size <= 0)
        break;

      if (sector_ofs == 0 && chunk_size == BLOCK_SECTOR_SIZE)
        {
          /* Write full sector directly to disk. */
          bc_write (sector_idx, buffer + bytes_written);
        }
      else
        {
          /* We need a bounce buffer. */
          if (bounce == NULL)
            {
              bounce = malloc (BLOCK_SECTOR_SIZE);
              if (bounce == NULL)
                break;
            }

          /* If the sector contains data before or after the chunk
             we're writing, then we need to read in the sector
             first.  Otherwise we start with a sector of all zeros. */
          if (sector_ofs > 0 || chunk_size < sector_left)
            bc_read (sector_idx, bounce);
          else
            memset (bounce, 0, BLOCK_SECTOR_SIZE);
          memcpy (bounce + sector_ofs, buffer + bytes_written, chunk_size);
          bc_write (sector_idx, bounce);
        }

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_written += chunk_size;
    }
  free (bounce);

  return bytes_written;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void
inode_deny_write (struct inode *inode)
{
  inode->deny_write_cnt++;
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void
inode_allow_write (struct inode *inode)
{
  ASSERT (inode->deny_write_cnt > 0);
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t
inode_length (const struct inode *inode)
{
  return inode->data.length;
}

static void inode_reserve_indirect(block_sector_t* sector, size_t sec_num, int level)//indirect�� reserve ���ش�
{
  static char zeros[BLOCK_SECTOR_SIZE];//block�� �Ҵ��
  struct inode_indirect_block_sector indirect_block;

	if(*sector == 0) {//allocate ���� �ʾҴ�. sector�� zeros�Ҵ�
		if(!free_map_allocate (1, sector)) return false;
		bc_write (*sector, zeros);
	}
	if(level==0)//level 0�̸� �� �� ����
		return;
	else
		bc_read(*sector,&indirect_block);//indirect block update(zeros�� ä����)
	if(level==1){
		for(size_t i=0;i<sec_num;i++){//�ʿ��� block����ŭ reserve
			inode_reserve_indirect(&indirect_block.blocks[i],1,level-1);//block �ϳ��� update
		}
	}
	else if (level==2){
		size_t len=DIV_ROUND_UP(sec_num,INDIRECT_BLOCKS_PER_SECTOR),size;
		for(size_t i=0;i<len;i++){//len�� �ʿ��� indirect block ��
			size=min(sec_num,INDIRECT_BLOCKS_PER_SECTOR);
			inode_reserve_indirect(&indirect_block.blocks[i],size,level-1);//indirect block �ϳ��� update
			sec_num-=size;
		}
	}
	bc_write(*sector,&indirect_block);
}

static bool inode_reserve (struct inode_disk *inode, off_t length)//extend inode in disk
{
	if (length < 0u) return false;

	size_t sec_num = bytes_to_sectors(length);//�������� sector ����
	size_t len = min(sec_num, DIRECT_BLOCKS_COUNT);
	for (size_t i = 0; i < len; i++) {//direct block �Ҵ�
		inode_reserve_indirect(&inode->direct_blocks[i],1,0);
	}
	sec_num -= len;//len ��ŭ ���� �Ϸ�
	if(sec_num == 0) return true;
///sec_num�� ����! indirect�� ����
	len = min(sec_num, INDIRECT_BLOCKS_PER_SECTOR);//�������� sector ����
	inode_reserve_indirect(&inode->indirect_block, len, 1);//len��ŭ indirect block�� ���� (level 1)
	sec_num -= len;
	if(sec_num == 0) return true;
//sec_num�� ����! doubly_indirect�� ����
	len = min(sec_num, INDIRECT_BLOCKS_PER_SECTOR * INDIRECT_BLOCKS_PER_SECTOR);//len��ŭ ��������
	inode_reserve_indirect (&inode->doubly_indirect_block, len, 2);//level 2�� doubly indirect�� ����
	sec_num -= len;//�� ���� �߾���� ��
	if(sec_num == 0) return true;
	return false;
}

static void inode_deallocate_indirect (block_sector_t sector, size_t sec_num, int level){
	struct inode_indirect_block_sector indirect_block;
	if (level == 0) {//direct block
		free_map_release (sector, 1);
		return;
	}
	else
		bc_read(sector, &indirect_block);//indirect block setting
	if(level==1){//indirect block
		for(size_t i=0;i<sec_num;i++){
			inode_deallocate_indirect(&indirect_block.blocks[i],1,level-1);
		}
	}
	else if(level==2){//doubly indirect block
		size_t len=DIV_ROUND_UP(sec_num,INDIRECT_BLOCKS_PER_SECTOR),size;
		for(size_t i=0;i<len;i++){
			size=min(sec_num,INDIRECT_BLOCKS_PER_SECTOR);
			inode_reserve_indirect(&indirect_block.blocks[i],size,level-1);//indirect block
			sec_num-=size;
		}
	}
	free_map_release(sector,1);
}

static bool inode_deallocate (struct inode *inode){
  if(inode->data.length < 0) return false;//deallocate �� �� ����

	size_t sec_num = bytes_to_sectors(inode->data.length);//deallocate�� sector ��
//deallocate direct block
	size_t len = min(sec_num, DIRECT_BLOCKS_COUNT);//deallocate direct block
		for (size_t i = 0; i < len; ++ i) {
			free_map_release (inode->data.direct_blocks[i], 1);
	}
	sec_num -= len;//���� sector ��
	if(sec_num==0)
		return true;
	len = min(sec_num, INDIRECT_BLOCKS_PER_SECTOR);
//////deallocate indirect block
	inode_deallocate_indirect (inode->data.indirect_block, len, 1);//level=1
	sec_num -= len;
	if(sec_num==0)
		return true;
	len = min(sec_num, INDIRECT_BLOCKS_PER_SECTOR * INDIRECT_BLOCKS_PER_SECTOR);
//////deallocate doubly indirect block
    inode_deallocate_indirect (inode->data.doubly_indirect_block, len, 2);//level=2
    sec_num -= len;
	if(sec_num==0)
		return true;
	return false;
}
bool inode_is_directory(const struct inode*inode){
	return inode->data.is_dir;
}
