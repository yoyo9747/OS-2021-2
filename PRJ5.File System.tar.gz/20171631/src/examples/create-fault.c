#include <stdio.h>

int main()
{
	create(42, 42);
	return 0;
}
