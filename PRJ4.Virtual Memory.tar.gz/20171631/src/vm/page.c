#include "vm/page.h"
#include <stdio.h>
#include <stdlib.h>
#include "lib/kernel/hash.h"
#include "threads/vaddr.h"
#include "threads/thread.h"
#include "userprog/process.h"
#include "userprog/syscall.h"
#include "threads/malloc.h"
#include "lib/stddef.h"
/*void vm_init(struct hash *vm){
	hash_init(vm,vm_hash_func,vm_less_func,NULL);		
}
unsigned vm_hash_func(const struct hash_elem *e, void *aux UNUSED){
	const struct vm_entry *p=hash_entry(e,struct vm_entry,elem);
	return hash_bytes(&p->vaddr,sizeof p->vaddr);
}
bool vm_less_func(const struct hash_elem *a,const struct hash_elem *b,void *aux UNUSED){
	const struct vm_entry *pa=hash_entry(a,struct vm_entry,elem);
	const struct vm_entry *pb=hash_entry(b,struct vm_entry,elem);

	return pa->vaddr<pb->vaddr;
}
bool insert_vme(struct hash *vm, struct vm_entry *vme){
	if(!hash_insert(vm,&vme->elem))
		return true;
	else
		return false;
}
bool delete_vme(struct hash *vm, struct vm_entry *vme){
	if(!hash_delete(vm,&vme->elem))
		return true;
	else
		return false;

}
struct vm_entry *find_vme(void *vaddr){
	struct vm_entry *p=(struct vm_entry*)malloc(sizeof(struct vm_entry));
	struct hash_elem *e;
	struct hash *table=&thread_current()->vm;

	p->vaddr=pg_round_down(vaddr);
	e=hash_find(table,&p->elem);

	free(p);

	return e!=NULL ? hash_entry(e,struct vm_entry,elem) : NULL;
}
void vm_destroy(struct hash *vm){
	hash_destroy(vm,NULL);
}
bool load_file(uint8_t* kaddr, struct vm_entry* vme){
	int temp;
	file_seek(vme->file,vme->offset);
	temp=file_read(vme->file,kaddr,vme->read_bytes);
	if(temp!=(int)vme->read_bytes){
		//palloc_free_page(kaddr);
		return false;
	}
	memset(kaddr+vme->read_bytes,0,vme->zero_bytes);
	return true;
}*/
